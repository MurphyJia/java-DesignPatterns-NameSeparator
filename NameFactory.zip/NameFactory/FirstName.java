package com.onjava8.DesignPatterns.NameFactory;

// This class is used to confirm the first name
public class FirstName extends Name{
    public FirstName(String str) {
        int i = str.lastIndexOf(" ");
        if(i > 0) {// If the name has a comma, then cut it into two parts
            firstName = str.substring(0, i).trim();
            lastName = str.substring(i+1).trim();
        } else {// If not, then do nothing
            firstName = "";
            lastName = str;
        }
    }
}
