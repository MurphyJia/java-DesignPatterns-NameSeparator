package com.onjava8.DesignPatterns.NameFactory;

public class NameFactory {
    /**
     * Get the input result and decide which instance would be created
     * @param name the input result
     * @return new LastName(name) create an instance of 'LastName' class
     * @retrun new FirstName(name) create an instance of 'FirstName' class
     */
    public Name getName(String name) {
        int i = name.indexOf(",");
        if(i > 0)
            return new LastName(name);
        else
            return new FirstName(name);
    }
}
