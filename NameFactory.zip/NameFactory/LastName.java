package com.onjava8.DesignPatterns.NameFactory;

// This class is used to confirm the last name
public class LastName extends Name{
    public LastName(String str) {
        int i = str.indexOf(",");
        if(i > 0) {// If the name has a comma, then cut it into two parts
            lastName = str.substring(0, i).trim();
            firstName = str.substring(i+1).trim();
        } else {// If not, do nothing
            lastName = str;
            firstName = "";
        }
    }
}
