package com.onjava8.DesignPatterns.NameFactory;

// This class is used to be a base class for subclasses to inherit
public class Name {
    protected static String firstName;
    protected static String lastName;
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}
