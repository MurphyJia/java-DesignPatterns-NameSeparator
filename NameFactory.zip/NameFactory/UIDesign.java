package com.onjava8.DesignPatterns.NameFactory;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.*;

import javax.swing.*;

// This class is used to design the UI page
@SuppressWarnings("serial")
public class UIDesign extends JFrame implements ActionListener {
    private final JButton compute = new JButton("Compute");
    private final JButton clear = new JButton("Clear");
    private final JButton close = new JButton("Close");
    JTextField enter = new JTextField(20);
    JTextField showFirstText = new JTextField(20);
    JTextField showLastText = new JTextField(20);

    /**
     * Set the styles of the buttons
     * @param b the button
     */
    public static void setButtonStyles(JButton b) {
        // The style of the button could be visible
        b.setVisible(true);
        // The button is set to be transparent so that it doesn't block the background behind it
        b.setOpaque(false);
        // The setting of removing the border of button in JButton in order to make the button better looking
        b.setContentAreaFilled(true);
        b.setBorder(BorderFactory.createRaisedBevelBorder());// Make the button appear convex effect
    }

    public UIDesign() {
        // Bottom Buttons
        JPanel buttons = new JPanel();
        buttons.add(compute);
        buttons.add(clear);
        buttons.add(close);

        setButtonStyles(compute);
        setButtonStyles(clear);
        setButtonStyles(close);

        buttons.setLayout(new GridLayout(1,3));
        buttons.setVisible(true);

        compute.addActionListener(this);
        clear.addActionListener(this);
        close.addActionListener(this);

        // tips
        JLabel message = new JLabel("Enter Name");

        // Above panel
        JPanel up = new JPanel();
        enter.setVisible(true);
        up.setVisible(true);
        message.setVisible(true);
        up.add(message, BorderLayout.CENTER);
        up.add(enter, BorderLayout.SOUTH);

        setLayout(new BorderLayout(120, 40));
        add(buttons, BorderLayout.SOUTH);
        add(up, BorderLayout.NORTH);

        JPanel output = new JPanel();
        add(output, BorderLayout.CENTER);

        // Show first name
        JPanel showFirst = new JPanel();
        JLabel first = new JLabel("First name（名） ：");
        first.setVisible(true);
        showFirst.add(first, BorderLayout.NORTH);
        showFirst.add(showFirstText, BorderLayout.WEST);
        output.add(showFirst, BorderLayout.NORTH);

        // Show Last name
        JPanel showLast = new JPanel();
        JLabel last = new JLabel("Last name（姓）：");
        last.setVisible(true);
        showLast.add(last, BorderLayout.NORTH);
        showLast.add(showLastText, BorderLayout.WEST);
        output.add(showLast, BorderLayout.SOUTH);

        setTitle("Name Divider（姓名分离器）");
        setVisible(true);
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(true);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        if(event.getSource() == compute) {
            new NameFactory().getName(enter.getText());
            showFirstText.setText(Name.firstName);
            showLastText.setText(Name.lastName);
        }  else if(event.getSource() == clear) {
            enter.setText("");
            showFirstText.setText("");
            showLastText.setText("");
        } else if(event.getSource() == close)
            System.exit(0);
    }

    public static void main(String[] args) {
        new UIDesign();
    }
}
